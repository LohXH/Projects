<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="stylesheet.css">
    <meta charset="UTF-8">
    <title>Library Read 2gether</title>
</head>
<?php
//link to header.html
include ('header.html');
?>
<body>

        <img src="images/lib.png" style="height: 100%; width: 100%"/>
		
</body>
</html>