package com.company;
import java.util.Scanner;
import java.util.Random;


class LocationDatabase
{
        static class Loc1 {
                int id = 1;
                String name = "Lotus's Semenyih";
                int area = 90 * 50;
                int avg_time = 40;
                int max_cap = area / 4;//divide 4 since there are 4 direction
        }

        static class Loc2 {
                int id = 2;
                String name = "MidValley";
                int area = 90 * 75;
                int avg_time = 60;
                int max_cap = area / 4;
        }

        static class Loc3 {
                int id = 3;
                String name = "Pavilion";
                int area = 60 * 80;
                int avg_time = 55;
                int max_cap = area / 4;
        }

        static class Loc4 {
                int id = 4;
                String name = "EcoHill";
                int area = 70 * 60;
                int avg_time = 45;
                int max_cap = area / 4;
        }

        static class Loc5{
                int id = 5;
                String name = "Aeon";
                int area = 65*70;
                int avg_time = 50;
                int max_cap =area/4;
        }
}

class SocialBubble {
        public static void direction(float north, float south, float east, float west, int select) {
                Random rd = new Random();
                if (north < 2.0 || south < 2.0 || east < 2.0 || west < 2.0) {
                        if (rd.nextBoolean()) {         //random boolean
                                System.out.println("You are in close contact with someone who has COVID-19");
                        } else {
                                System.out.println("Please practice social distancing. Thank you for your cooperation");

                        }

                }

                switch (select) {
                //switch statement for casual contact
                        case 1 -> {
                                LocationDatabase.Loc1 L1 = new LocationDatabase.Loc1();
                                System.out.println("ID: 20308801");
                                System.out.println("Name: Loh Xin Herng");
                                System.out.println("Location ID: " + L1.id);
                                System.out.println("Location Name:" + L1.name);
                                System.out.println("Date:"+java.time.LocalDate.now());
                                System.out.println("Time:"+java.time.LocalTime.now());
                                System.out.println("Status: Casual Contact");

                        }
                        case 2 -> {
                                LocationDatabase.Loc2 L2 = new LocationDatabase.Loc2();
                                System.out.println("ID: 20308801");
                                System.out.println("Name: Loh Xin Herng");
                                System.out.println("Location ID: " + L2.id);
                                System.out.println("Location Name:" + L2.name);
                                System.out.println("Date:"+java.time.LocalDate.now());
                                System.out.println("Time:"+java.time.LocalTime.now());
                                System.out.println("Status: Casual Contact");

                        }
                        case 3 -> {
                                LocationDatabase.Loc3 L3 = new LocationDatabase.Loc3();
                                System.out.println("ID: 20308801");
                                System.out.println("Name: Loh Xin Herng");
                                System.out.println("Location ID: " + L3.id);
                                System.out.println("Location Name:" + L3.name);
                                System.out.println("Date:"+java.time.LocalDate.now());
                                System.out.println("Time:"+java.time.LocalTime.now());
                                System.out.println("Status: Casual Contact");

                        }
                        case 4 -> {
                                LocationDatabase.Loc4 L4 = new LocationDatabase.Loc4();
                                System.out.println("ID: 20308801");
                                System.out.println("Name: Loh Xin Herng");
                                System.out.println("Location ID: " + L4.id);
                                System.out.println("Location Name:" + L4.name);
                                System.out.println("Date:"+java.time.LocalDate.now());
                                System.out.println("Time:"+java.time.LocalTime.now());
                                System.out.println("Status: Casual Contact");

                        }
                        case 5 -> {
                                LocationDatabase.Loc5 L5 = new LocationDatabase.Loc5();
                                System.out.println("ID: 20308801");
                                System.out.println("Name: Loh Xin Herng");
                                System.out.println("Location ID: " + L5.id);
                                System.out.println("Location Name:" + L5.name);
                                System.out.println("Date:"+java.time.LocalDate.now());
                                System.out.println("Time:"+java.time.LocalTime.now());
                                System.out.println("Status: Casual Contact");

                        }
                }

        }

        public static void print_normal(int select) {
                switch (select) {
                //switch statement for normal condition
                        case 1 -> {
                                LocationDatabase.Loc1 L1 = new LocationDatabase.Loc1();
                                System.out.println("ID: 20308801");
                                System.out.println("Name: Loh Xin Herng");
                                System.out.println("Location ID: " + L1.id);
                                System.out.println("Location Name:" + L1.name);
                                System.out.println("Date:"+java.time.LocalDate.now());
                                System.out.println("Time:"+java.time.LocalTime.now());
                                System.out.println("Status: Low Risk No Symptoms");

                        }
                        case 2 -> {
                                LocationDatabase.Loc2 L2 = new LocationDatabase.Loc2();
                                System.out.println("ID: 20308801");
                                System.out.println("Name: Loh Xin Herng");
                                System.out.println("Location ID: " + L2.id);
                                System.out.println("Location Name:" + L2.name);
                                System.out.println("Date:"+java.time.LocalDate.now());
                                System.out.println("Time:"+java.time.LocalTime.now());
                                System.out.println("Status: Low Risk No Symptoms");

                        }
                        case 3 -> {
                                LocationDatabase.Loc3 L3 = new LocationDatabase.Loc3();
                                System.out.println("ID: 20308801");
                                System.out.println("Name: Loh Xin Herng");
                                System.out.println("Location ID: " + L3.id);
                                System.out.println("Location Name:" + L3.name);
                                System.out.println("Date:"+java.time.LocalDate.now());
                                System.out.println("Time:"+java.time.LocalTime.now());
                                System.out.println("Status: Low Risk No Symptoms");

                        }
                        case 4 -> {
                                LocationDatabase.Loc4 L4 = new LocationDatabase.Loc4();
                                System.out.println("ID: 20308801");
                                System.out.println("Name: Loh Xin Herng");
                                System.out.println("Location ID: " + L4.id);
                                System.out.println("Location Name:" + L4.name);
                                System.out.println("Date:"+java.time.LocalDate.now());
                                System.out.println("Time:"+java.time.LocalTime.now());
                                System.out.println("Status: Low Risk No Symptoms");

                        }
                        case 5 -> {
                                LocationDatabase.Loc5 L5 = new LocationDatabase.Loc5();
                                System.out.println("ID: 20308801");
                                System.out.println("Name: Loh Xin Herng");
                                System.out.println("Location ID: " + L5.id);
                                System.out.println("Location Name:" + L5.name);
                                System.out.println("Date:"+java.time.LocalDate.now());
                                System.out.println("Time:"+java.time.LocalTime.now());
                                System.out.println("Status: Low Risk No Symptom");

                        }
                }
        }
}



        public class ProactiveSD extends SocialBubble {

                public static void main(String[] args) {
                        Scanner input = new Scanner(System.in);
                        Random rand = new Random();
                        int loc = 0;
                        int flag = 1;
                        while (flag == 1) {
                                System.out.println("Enter LocationID 1-5: ");
                                loc = input.nextInt();
                                switch (loc) {
                                        //main menu
                                        case 1 -> {
                                                LocationDatabase.Loc1 L1 = new LocationDatabase.Loc1();
                                                System.out.println("LocationID:" + L1.id);
                                                System.out.println("Location:" + L1.name);
                                                System.out.println("Area:" + L1.area);
                                                System.out.println("Average time per person:" + L1.avg_time);
                                                System.out.println("Capacity:" + L1.max_cap);
                                                System.out.println("\n");
                                                int x = rand.nextInt(1126);//random capacity
                                                //int x = 1126;  to check output when capacity is full
                                                if (x >= 1125) {
                                                        System.out.println("The current capacity is:" + x);
                                                        System.out.println("The current location has reached its maximum capacity");
                                                        Scanner choice = new Scanner(System.in);
                                                        System.out.println("Estimated waiting time is 40 minutes, do you want to wait(Y/N)?:");
                                                        String resp = choice.nextLine();
                                                        if (resp.equals("Y") || resp.equals("y")) {
                                                                System.out.println("Waiting...");
                                                                System.out.println("You may enter now");
                                                        } else continue;

                                                } else {
                                                        System.out.println("The current capacity is:" + x);
                                                        System.out.println("You may enter now");

                                                }
                                                flag = 0;

                                        }
                                        case 2 -> {
                                                LocationDatabase.Loc2 L2 = new LocationDatabase.Loc2();
                                                System.out.println("LocationID:" + L2.id);
                                                System.out.println("Location:" + L2.name);
                                                System.out.println("Area:" + L2.area);
                                                System.out.println("Average time per person:" + L2.avg_time);
                                                System.out.println("Capacity:" + L2.max_cap);
                                                System.out.println("\n");
                                                int x = rand.nextInt(1688);
                                                //int x = 1688;
                                                if (x >= 1687) {
                                                        System.out.println("The current capacity is:" + x);
                                                        System.out.println("The current location has reached its maximum capacity");
                                                        Scanner choice = new Scanner(System.in);
                                                        System.out.println("Estimated waiting time is 40 minutes, do you want to wait(Y/N)?:");
                                                        String resp = choice.nextLine();
                                                        if (resp.equals("Y") || resp.equals("y")) {
                                                                System.out.println("Waiting...");
                                                                System.out.println("You may enter now");
                                                        } else continue;
                                                } else {
                                                        System.out.println("The current capacity is:" + x);
                                                        System.out.println("You may enter now");

                                                }
                                                flag = 0;
                                        }
                                        case 3 -> {
                                                LocationDatabase.Loc3 L3 = new LocationDatabase.Loc3();
                                                System.out.println("LocationID:" + L3.id);
                                                System.out.println("Location:" + L3.name);
                                                System.out.println("Area:" + L3.area);
                                                System.out.println("Average time per person:" + L3.avg_time);
                                                System.out.println("Capacity:" + L3.max_cap);
                                                System.out.println("\n");
                                                int x = rand.nextInt(1201);
                                                //int x = 1201;
                                                if (x >= 1200) {
                                                        System.out.println("The current capacity is:" + x);
                                                        System.out.println("The current location has reached its maximum capacity");
                                                        Scanner choice = new Scanner(System.in);
                                                        System.out.println("Estimated waiting time is 55 minutes, do you want to wait(Y/N)?:");
                                                        String resp = choice.nextLine();
                                                        if (resp.equals("Y") || resp.equals("y")) {
                                                                System.out.println("Waiting...");
                                                                System.out.println("You may enter now");
                                                        } else continue;
                                                } else {
                                                        System.out.println("The current capacity is:" + x);
                                                        System.out.println("You may enter now");

                                                }
                                                flag = 0;
                                        }
                                        case 4 -> {
                                                LocationDatabase.Loc4 L4 = new LocationDatabase.Loc4();
                                                System.out.println("LocationID:" + L4.id);
                                                System.out.println("Location:" + L4.name);
                                                System.out.println("Area:" + L4.area);
                                                System.out.println("Average time per person:" + L4.avg_time);
                                                System.out.println("Capacity:" + L4.max_cap);
                                                System.out.println("\n");
                                                int x = rand.nextInt(1051);
                                                //int x = 1051;
                                                if (x >= 1050) {
                                                        System.out.println("The current capacity is:" + x);
                                                        System.out.println("The current location has reached its maximum capacity");
                                                        Scanner choice = new Scanner(System.in);
                                                        System.out.println("Estimated waiting time is 40 minutes, do you want to wait(Y/N)?:");
                                                        String resp = choice.nextLine();
                                                        if (resp.equals("Y") || resp.equals("y")) {
                                                                System.out.println("Waiting...");
                                                                System.out.println("You may enter now");
                                                        } else continue;
                                                } else {
                                                        System.out.println("The current capacity is:" + x);
                                                        System.out.println("You may enter now");

                                                }
                                                flag = 0;
                                        }
                                        case 5 -> {
                                                LocationDatabase.Loc5 L5 = new LocationDatabase.Loc5();
                                                System.out.println("LocationID:" + L5.id);
                                                System.out.println("Location:" + L5.name);
                                                System.out.println("Area:" + L5.area);
                                                System.out.println("Average time per person:" + L5.avg_time);
                                                System.out.println("Capacity:" + L5.max_cap);
                                                System.out.println("\n");
                                                int x = rand.nextInt(1138);
                                                //int x = 1138;
                                                if (x >= 1137) {
                                                        System.out.println("The current capacity is:" + x);
                                                        System.out.println("The current location has reached its maximum capacity");
                                                        Scanner choice = new Scanner(System.in);
                                                        System.out.println("Estimated waiting time is 40 minutes, do you want to wait(Y/N)?:");
                                                        String resp = choice.nextLine();
                                                        if (resp.equals("Y") || resp.equals("y")) {
                                                                System.out.println("Waiting...");
                                                                System.out.println("You may enter now");
                                                        } else continue;
                                                } else {
                                                        System.out.println("The current capacity is:" + x);
                                                        System.out.println("You may enter now");

                                                }
                                                flag = 0;
                                        }
                                        default -> {
                                                System.out.println("Invalid number, Please try again");
                                                System.out.println("\n");
                                        }
                                }
                        }
                        Scanner direction = new Scanner(System.in);
                        System.out.println("Please enter distance from four directions");
                        System.out.println("North:");
                        float north = direction.nextFloat();
                        System.out.println("South:");
                        float south = direction.nextFloat();
                        System.out.println("East:");
                        float east = direction.nextFloat();
                        System.out.println("West:");
                        float west = direction.nextFloat();
                        if (north >= 2.0 && south >= 2.0 && east >= 2.0 && west >= 2.0) {
                                System.out.println("Good job! Thank you for practising social distancing");
                                print_normal(loc);
                        }
                        if ((north < 2.0) || (south < 2.0) || (east < 2.0) || (west < 2.0)){
                                direction(north,south,east,west,loc);
                        }
                }
        }



